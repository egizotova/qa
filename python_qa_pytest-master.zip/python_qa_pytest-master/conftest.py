import pytest

# @pytest.fixture()
# def first_fixture():
#     print("\nPrint from 'first_fixture' in conftest.py root")
